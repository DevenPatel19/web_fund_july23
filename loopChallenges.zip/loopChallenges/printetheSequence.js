// Print the sequence
// Using a loop write code that will console.log the values in this sequence 4, 2.5, 1, -0.5, -2, -3.5.

for (var i = 4; i > -4; i-=1.5) {
    console.log(i);
}
